#!/usr/bin/env python3
"""Apply MIDIJAQ-only changes to the exact a4f2d1e source checkout.

Works offline after the source checkout exists. Writes no files in any other branch. Creates
backups only when requested; git diff is the normal way to review changes before committing.
"""
from pathlib import Path
import subprocess
import sys
import os

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
source = Path(__file__).resolve().parent

def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.DEVNULL, text=True).strip()

try:
    branch = git('branch', '--show-current')
    head = git('rev-parse', 'HEAD')
    dirty = git('status', '--porcelain')
except (subprocess.CalledProcessError, FileNotFoundError):
    raise SystemExit('Please use a Git checkout of the midijaq branch; nothing was changed.')
if branch != 'midijaq':
    raise SystemExit(f'Only the midijaq branch may be edited (currently {branch}). Nothing was changed.')
if head != 'a4f2d1ec034f2f2ef5b6541df08222a0c14e9e49' and os.environ.get('MIDIJAQ_CI_BUILD') != '1':
    raise SystemExit(f'This patch was made for a4f2d1e, not {head[:8]}. Nothing was changed.')
if dirty:
    raise SystemExit('The checkout contains changes. Work from a clean midijaq checkout so none are overwritten.')
files = {}

def edit(path):
    p = root / path
    if not p.is_file(): raise SystemExit(f'Missing {path}; run this from a midijaq source checkout')
    files[path] = p.read_text(encoding='utf-8')
    return files[path]

def replace(path, original, changed):
    text = files[path]
    hits = text.count(original)
    if hits != 1: raise SystemExit(f'Expected one match in {path}, found {hits}: {original[:72]!r}. No files were written.')
    files[path] = text.replace(original, changed, 1)

edit('Source/core/Jaq.h')
replace('Source/core/Jaq.h',
    'enum class Mode : uint8_t { Free = 0, Follow, Bass };',
    'enum class Mode : uint8_t { Free = 0, Follow, Bass, Parts };')
replace('Source/core/Jaq.h',
    '    Mode mode = Mode::Free;\n};',
    '    Mode mode = Mode::Free;\n    int partIndex = 0;               // Parts: which voice of the chord this line carries\n};')
replace('Source/core/Jaq.h',
    '    int low = held[0];\n    for (int i = 1; i < numHeld; ++i) low = std::min (low, held[i]);',
    '''    if (L.mode == Mode::Parts)
    {
        const int voice = std::max (0, std::min (numHeld - 1, L.partIndex));
        return std::max (0, std::min (127, held[voice] + 12 * e.octave + L.transpose));
    }
    int low = held[0];
    for (int i = 1; i < numHeld; ++i) low = std::min (low, held[i]);''')

edit('Source/core/Player.h')
replace('Source/core/Player.h', '#include "Jaq.h"', '#include "Jaq.h"\n#include "Session.h"')
replace('Source/core/Player.h',
    '                 MidiOut* out, int maxOut)\n',
    '''                 MidiOut* out, int maxOut, const Progression* progression = nullptr,
                 const GeneratorSettings* writer = nullptr, double chordBeat = 0.0)
''')
replace('Source/core/Player.h',
    '                for (const auto& e : pass.events)\n                {',
    '''                bool prevPassed = true;
                for (const auto& e : pass.events)
                {
                    const bool permitted = writer == nullptr || cueAllows (*writer, (uint64_t) std::max (0ll, k), e.step, prevPassed);
                    prevPassed = permitted;
                    if (! permitted) continue;''')
replace('Source/core/Player.h',
    '''                    const int note = notePlayed (L, e, held.data(), numHeld);
                    const int velocity = (L.mode == Mode::Free || numHeld == 0)
                                       ? e.velocity
                                       : std::max (1, std::min (127, (int) std::lround ((double) e.velocity * (double) keyVelocity() / 100.0)));''',
    '''                    ChordNotes chord;
                    const int* pitchKeys = held.data();
                    int numPitchKeys = numHeld;
                    if (progression != nullptr && (L.mode == Mode::Bass || L.mode == Mode::Parts))
                    {
                        chord = progression->notesAt (t + chordBeat);
                        pitchKeys = chord.notes.data();
                        numPitchKeys = chord.count;
                    }
                    const int note = notePlayed (L, e, pitchKeys, numPitchKeys);
                    const int velocity = (L.mode == Mode::Free || numHeld == 0 || (progression != nullptr && (L.mode == Mode::Bass || L.mode == Mode::Parts)))
                                       ? e.velocity
                                       : std::max (1, std::min (127, (int) std::lround ((double) e.velocity * (double) keyVelocity() / 100.0)));''')

# Audio snapshot values are immutable after publishing. The editor's working line remains its existing API.
edit('Source/app/Processor.h')
replace('Source/app/Processor.h', '#include "../core/Player.h"', '#include "../core/Player.h"\n#include "../core/Session.h"')
replace('Source/app/Processor.h',
    '    mjq::Line line;                                  // the message thread owns this\n    mjq::Player player;',
    '''    mjq::Line line;                                  // the selected line, on the message thread
    mjq::Session session;                             // 128 slots, four lines, chord track
    mjq::Player player;                               // line 1, kept for the original public API
    std::array<mjq::Player, mjq::kSessionTracks - 1> otherPlayers;
    std::array<mjq::InstrumentPlayer, mjq::kSessionTracks - 1> otherVoices;
    void setInstrumentLevel (float level);
    int chosenSlot() const noexcept { return session.selected; }
    int chosenTrack() const noexcept { return session.selectedTrack; }
    void chooseSlot (int index);
    void chooseTrack (int index);
    void changeWriter (mjq::Generator);
    void changeChord (int bar, const mjq::Chord&);
    void changeChain (int length);
    void changeTrackEnabled (bool enabled);
    bool savePatterns (const juce::File&, juce::String& error);
    bool loadPatterns (const juce::File&, juce::String& error);
    void rebuildSession (bool full = false);''')
replace('Source/app/Processor.h',
    '    std::shared_ptr<const mjq::Pass> shown;          // swapped under the audio thread\'s feet, never edited',
    '''    struct Prepared
    {
        mjq::Session state;
        std::array<std::array<mjq::Pass, mjq::kSessionTracks>, mjq::kSessionSlots> passes {};
    };
    std::shared_ptr<const Prepared> prepared;
    std::shared_ptr<const mjq::Pass> shown;          // editor's preview of the chosen line''')
replace('Source/app/Processor.h',
    '    std::atomic<int> lastStep { -1 };',
    '''    std::atomic<int> lastStep { -1 };
    double hostSampleRate = 48000.0;
    int playingSlot = -1;''')

replace('Source/app/Processor.h', '    std::vector<mjq::Line> undoStack, redoStack;',
    '    struct History { int slot, track; mjq::Line line; };\n    std::vector<History> undoStack, redoStack;')

edit('Source/app/Processor.cpp')
replace('Source/app/Processor.cpp',
    'void MjqProcessor::mark()\n{\n    undoStack.push_back (line);\n    if (undoStack.size() > 64) undoStack.erase (undoStack.begin());\n    redoStack.clear();\n}\n\nbool MjqProcessor::undo()\n{\n    if (undoStack.empty()) return false;\n    redoStack.push_back (line);\n    line = undoStack.back();\n    undoStack.pop_back();\n    lineChanged();\n    return true;\n}\n\nbool MjqProcessor::redo()\n{\n    if (redoStack.empty()) return false;\n    undoStack.push_back (line);\n    line = redoStack.back();\n    redoStack.pop_back();\n    lineChanged();\n    return true;\n}\n',
    'void MjqProcessor::mark()\n{\n    undoStack.push_back ({ session.selected, session.selectedTrack, line });\n    if (undoStack.size() > 64) undoStack.erase (undoStack.begin());\n    redoStack.clear();\n}\n\nbool MjqProcessor::undo()\n{\n    if (undoStack.empty()) return false;\n    redoStack.push_back ({ session.selected, session.selectedTrack, line });\n    const auto prev = undoStack.back();\n    undoStack.pop_back();\n    chooseSlot (prev.slot);\n    chooseTrack (prev.track);\n    line = prev.line;\n    lineChanged();\n    return true;\n}\n\nbool MjqProcessor::redo()\n{\n    if (redoStack.empty()) return false;\n    undoStack.push_back ({ session.selected, session.selectedTrack, line });\n    const auto next = redoStack.back();\n    redoStack.pop_back();\n    chooseSlot (next.slot);\n    chooseTrack (next.track);\n    line = next.line;\n    lineChanged();\n    return true;\n}\n')
replace('Source/app/Processor.cpp',
    '''    mjq::generate (line, (uint32_t) juce::Random::getSystemRandom().nextInt (1000000) + 1);
    lineChanged();''',
    '''    line = session.current().tracks[0].line;
    rebuildSession (true);''')
replace('Source/app/Processor.cpp',
    '''void MjqProcessor::lineChanged()
{
    auto p = std::make_shared<mjq::Pass> (mjq::readPass (line));
    std::atomic_store (&shown, std::shared_ptr<const mjq::Pass> (std::move (p)));
    version.fetch_add (1);
}
''',
    '''void MjqProcessor::rebuildSession (bool full)
{
    auto& track = session.current().tracks[(size_t) session.selectedTrack];
    track.line = line;
    track.line.partIndex = session.selectedTrack;
    session.touched[(size_t) session.selected] = true;
    auto old = std::atomic_load (&prepared);
    auto next = old != nullptr ? std::make_shared<Prepared> (*old) : std::make_shared<Prepared>();
    next->state = session;
    if (full || old == nullptr)
    {
        for (int s = 0; s < mjq::kSessionSlots; ++s)
            for (int t = 0; t < mjq::kSessionTracks; ++t)
                next->passes[(size_t) s][(size_t) t] = mjq::generatedPass (next->state.slots[(size_t) s].tracks[(size_t) t]);
    }
    else
    {
        for (int t = 0; t < mjq::kSessionTracks; ++t)
            next->passes[(size_t) session.selected][(size_t) t] = mjq::generatedPass (next->state.current().tracks[(size_t) t]);
    }
    const auto& preview = next->passes[(size_t) session.selected][(size_t) session.selectedTrack];
    std::atomic_store (&shown, std::shared_ptr<const mjq::Pass> (std::make_shared<mjq::Pass> (preview)));
    std::atomic_store (&prepared, std::shared_ptr<const Prepared> (std::move (next)));
    version.fetch_add (1);
}

void MjqProcessor::lineChanged() { rebuildSession(); }

void MjqProcessor::chooseSlot (int index)
{
    session.current().tracks[(size_t) session.selectedTrack].line = line;
    session.selected = juce::jlimit (0, mjq::kSessionSlots - 1, index);
    line = session.current().tracks[(size_t) session.selectedTrack].line;
    rebuildSession();
}

void MjqProcessor::chooseTrack (int index)
{
    session.current().tracks[(size_t) session.selectedTrack].line = line;
    session.selectedTrack = juce::jlimit (0, mjq::kSessionTracks - 1, index);
    line = session.current().tracks[(size_t) session.selectedTrack].line;
    line.partIndex = session.selectedTrack;
    rebuildSession();
}

void MjqProcessor::changeWriter (mjq::Generator writer)
{
    session.current().tracks[(size_t) session.selectedTrack].generator.kind = writer;
    rebuildSession();
}

void MjqProcessor::changeChord (int bar, const mjq::Chord& chord)
{
    session.current().chords.bars[(size_t) juce::jlimit (0, mjq::kChordBars - 1, bar)] = chord;
    rebuildSession();
}

void MjqProcessor::changeChain (int length)
{
    session.chainLength = juce::jlimit (1, mjq::kSessionSlots, length);
    rebuildSession();
}

void MjqProcessor::changeTrackEnabled (bool enabled)
{
    session.current().tracks[(size_t) session.selectedTrack].enabled = enabled;
    rebuildSession();
}

void MjqProcessor::setInstrumentLevel (float level)
{
    voices.level.store (level);
    for (auto& v : otherVoices) v.level.store (level);
}
''')
replace('Source/app/Processor.cpp',
    '''    player.prepare (sampleRate);
    player.allKeysUp();''',
    '''    hostSampleRate = sampleRate;
    playingSlot = -1;
    player.prepare (sampleRate);
    player.allKeysUp();
    for (auto& p : otherPlayers) { p.prepare (sampleRate); p.allKeysUp(); }''')
replace('Source/app/Processor.cpp',
    '''        if (msg.isNoteOn())            player.keyDown (msg.getNoteNumber(), msg.getVelocity());
        else if (msg.isNoteOff())      player.keyUp (msg.getNoteNumber());
        else if (msg.isAllNotesOff())  player.allKeysUp();''',
    '''        auto key = [&] (mjq::Player& p)
        {
            if (msg.isNoteOn())            p.keyDown (msg.getNoteNumber(), msg.getVelocity());
            else if (msg.isNoteOff())      p.keyUp (msg.getNoteNumber());
            else if (msg.isAllNotesOff())  p.allKeysUp();
        };
        key (player);
        for (auto& p : otherPlayers) key (p);''')
# More replacements below: whole old process body after MIDI input
replace('Source/app/Processor.cpp',
    '''    auto snapshot = std::atomic_load (&shown);
    if (snapshot == nullptr) return;

    mjq::HostTime host;''',
    '''    auto snapshot = std::atomic_load (&prepared);
    if (snapshot == nullptr) return;

    mjq::HostTime host;''')
replace('Source/app/Processor.cpp',
    '''    mjq::MidiOut out[256];
    const int n = player.process (line, *snapshot, clockMode, host, audio.getNumSamples(), out, 256);
    for (int i = 0; i < n; ++i)
        midi.addEvent (out[i].on ? juce::MidiMessage::noteOn (1, out[i].note, (juce::uint8) out[i].velocity)
                                 : juce::MidiMessage::noteOff (1, out[i].note),
                       out[i].sample);

    // the same notes play the instrument, when one is loaded: MidiJaQ makes its own sound as well as MIDI
    mjq::PlayNote notes[256];
    for (int i = 0; i < n; ++i)
        notes[i] = { out[i].sample, out[i].note, (float) out[i].velocity / 127.0f, out[i].on };
    voices.process (audio.getWritePointer (0), audio.getNumChannels() > 1 ? audio.getWritePointer (1) : audio.getWritePointer (0),
                    audio.getNumSamples(), notes, n);

    lastStep.store (player.stepNow (*snapshot));''',
    '''    // Split at bar boundaries so changing a slot never fires notes from the next slot early.
    // Every line has its own player and MIDI channel; the players share the host clock.
    mjq::PlayNote notes[mjq::kSessionTracks][1024];
    int numNotes[mjq::kSessionTracks] {};
    const int total = audio.getNumSamples();
    const double bpm = host.bpm > 1.0 ? host.bpm : 120.0;
    const double beatPerSample = bpm / (60.0 * std::max (1.0, hostSampleRate));
    int start = 0;
    while (start < total)
    {
        const double beat = host.ppq + start * beatPerSample;
        const uint64_t bar = (uint64_t) std::floor (std::max (0.0, beat) / 4.0);
        const int slotNumber = (host.valid && host.playing && snapshot->state.chainLength > 1)
                             ? snapshot->state.slotAtBar (bar)
                             : snapshot->state.selected;
        const auto& slot = snapshot->state.slots[(size_t) slotNumber];
        const auto& passes = snapshot->passes[(size_t) slotNumber];

        int segment = total - start;
        if (host.valid && host.playing && snapshot->state.chainLength > 1)
        {
            const double nextBar = ((double) bar + 1.0) * 4.0;
            segment = std::min (segment, std::max (1, (int) std::ceil ((nextBar - beat) / beatPerSample - 1.0e-7)));
        }

        auto emit = [&] (int track, const mjq::MidiOut& e)
        {
            const int sample = start + e.sample;
            midi.addEvent (e.on ? juce::MidiMessage::noteOn (track + 1, e.note, (juce::uint8) e.velocity)
                                : juce::MidiMessage::noteOff (track + 1, e.note), sample);
            if (numNotes[track] < 1024)
                notes[track][numNotes[track]++] = { sample, e.note, (float) e.velocity / 127.0f, e.on };
        };

        if (slotNumber != playingSlot)
        {
            for (int track = 0; track < mjq::kSessionTracks; ++track)
            {
                auto& seq = track == 0 ? player : otherPlayers[(size_t) (track - 1)];
                mjq::MidiOut released[64];
                const int count = seq.releaseAllNow (released, 64);
                for (int j = 0; j < count; ++j) emit (track, released[j]);
                seq.reset();
            }
            playingSlot = slotNumber;
        }

        mjq::HostTime segmentTime = host;
        if (host.valid) segmentTime.ppq = beat;
        for (int track = 0; track < mjq::kSessionTracks; ++track)
        {
            auto& seq = track == 0 ? player : otherPlayers[(size_t) (track - 1)];
            if (! slot.tracks[(size_t) track].enabled)
            {
                mjq::MidiOut released[64];
                const int count = seq.releaseAllNow (released, 64);
                for (int j = 0; j < count; ++j) emit (track, released[j]);
                seq.reset();
                continue;
            }
            mjq::MidiOut out[256];
            const auto& tr = slot.tracks[(size_t) track];
            const int count = seq.process (tr.line, passes[(size_t) track], clockMode, segmentTime,
                                           segment, out, 256, &slot.chords, &tr.generator);
            for (int j = 0; j < count; ++j) emit (track, out[j]);
        }
        start += segment;
    }

    // One instrument plays the notes from all active lines. Keep the events in sample order for the
    // shared voice player, which is also used by Batchcut.
    for (int track = 0; track < mjq::kSessionTracks; ++track)
    {
        std::sort (notes[track], notes[track] + numNotes[track], [] (const mjq::PlayNote& a, const mjq::PlayNote& b)
        {
            if (a.offset != b.offset) return a.offset < b.offset;
            return ! a.on && b.on; // a retrigger releases the earlier voice before its new attack
        });
        auto& v = track == 0 ? voices : otherVoices[(size_t) (track - 1)];
        v.process (audio.getWritePointer (0), audio.getNumChannels() > 1 ? audio.getWritePointer (1) : audio.getWritePointer (0),
                   audio.getNumSamples(), notes[track], numNotes[track]);
    }

    lastStep.store (player.stepNow (snapshot->passes[(size_t) snapshot->state.selected][0]));''')
replace('Source/app/Processor.cpp', '    root.setAttribute ("mode", (int) L.mode);',
    '    root.setAttribute ("mode", (int) L.mode);\n    root.setAttribute ("partIndex", L.partIndex);')
replace('Source/app/Processor.cpp',
    '    L.mode = (mjq::Mode) juce::jlimit (0, 2, root->getIntAttribute ("mode", 0));',
    '    L.mode = (mjq::Mode) juce::jlimit (0, 3, root->getIntAttribute ("mode", 0));\n    L.partIndex = juce::jlimit (0, 3, root->getIntAttribute ("partIndex", 0));')
# Keep the old per-line reader and writer for legacy projects and tests. New projects save the entire bank.
replace('Source/app/Processor.cpp',
    'void MjqProcessor::getStateInformation (juce::MemoryBlock& dest)',
    """bool MjqProcessor::savePatterns (const juce::File& destination, juce::String& error)
{
    juce::MemoryBlock project;
    getStateInformation (project);
    auto state = juce::parseXML (juce::String::fromUTF8 ((const char*) project.getData(), (int) project.getSize()));
    if (state == nullptr) { error = "Could not read the saved pattern."; return false; }
    juce::XmlElement manifest ("NJQ");
    manifest.setAttribute ("version", 2);
    manifest.setAttribute ("kind", "pattern");
    manifest.setAttribute ("name", destination.getFileNameWithoutExtension());
    manifest.setAttribute ("madeWith", "MidiJaQ");
    manifest.addChildElement (state.release());
    const auto xml = manifest.toString();
    juce::ZipFile::Builder zip;
    zip.addEntry (new juce::MemoryInputStream (xml.toRawUTF8(), xml.getNumBytesAsUTF8(), true),
                  9, "manifest.xml", juce::Time::getCurrentTime());
    const auto tmp = destination.getSiblingFile (destination.getFileName() + ".part");
    tmp.deleteFile();
    {
        juce::FileOutputStream out (tmp);
        if (! out.openedOk() || ! zip.writeToStream (out, nullptr))
        { tmp.deleteFile(); error = "Could not save " + destination.getFileName(); return false; }
        out.flush();
    }
    if (! tmp.moveFileTo (destination))
    { tmp.deleteFile(); error = "Could not finish saving " + destination.getFileName(); return false; }
    message = "Saved " + destination.getFileName();
    version.fetch_add (1);
    return true;
}

bool MjqProcessor::loadPatterns (const juce::File& file, juce::String& error)
{
    if (! file.existsAsFile()) { error = "The file is not there."; return false; }
    juce::ZipFile zip (file);
    auto* entry = zip.getEntry ("manifest.xml");
    if (entry == nullptr) { error = "Not a .NJQ file."; return false; }
    std::unique_ptr<juce::InputStream> stream (zip.createStreamForEntry (*entry));
    if (! stream) { error = "Could not read the pattern."; return false; }
    auto manifest = juce::parseXML (stream->readEntireStreamAsString());
    if (! manifest || ! manifest->hasTagName ("NJQ") || manifest->getStringAttribute ("kind") != "pattern")
    { error = "This is not a MidiJaQ pattern."; return false; }
    auto* state = manifest->getChildByName ("MIDIJAQ_SESSION");
    if (! state) { error = "No MidiJaQ pattern was found."; return false; }
    const auto data = state->toString();
    setStateInformation (data.toRawUTF8(), data.getNumBytesAsUTF8());
    message = "Opened " + file.getFileName();
    version.fetch_add (1);
    return true;
}

void MjqProcessor::getStateInformation (juce::MemoryBlock& dest)""")
replace('Source/app/Processor.cpp',
    '''void MjqProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    const auto xml = toXml (line, clockMode, instrumentFile);
    dest.replaceAll (xml.toRawUTF8(), xml.getNumBytesAsUTF8());
}

void MjqProcessor::setStateInformation (const void* data, int size)
{
    if (data == nullptr || size <= 0) return;
    mjq::Line L;
    auto clock = clockMode;
    juce::String wants;
    if (! fromXml (juce::String::fromUTF8 ((const char*) data, size), L, clock, wants)) return;
    line = L;
    clockMode = clock;
    lineChanged();

    // the instrument travels as a path: the project opens it again if it is still there
    if (wants.isNotEmpty() && wants != instrumentFile)
    {
        const juce::File f (wants);
        juce::String err;
        if (f.existsAsFile()) openInstrument (f, err);
        else { instrumentFile = wants; message = "The instrument " + f.getFileName() + " was not where it was: open it again."; version.fetch_add (1); }
    }
}
''',
    '''void MjqProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    session.current().tracks[(size_t) session.selectedTrack].line = line;
    juce::XmlElement root ("MIDIJAQ_SESSION");
    root.setAttribute ("version", 2);
    root.setAttribute ("selected", session.selected);
    root.setAttribute ("selectedTrack", session.selectedTrack);
    root.setAttribute ("chain", session.chainLength);
    root.setAttribute ("clock", (int) clockMode);
    root.setAttribute ("instrument", instrumentFile);
    for (int s = 0; s < mjq::kSessionSlots; ++s)
    {
        if (! session.touched[(size_t) s]) continue;
        const auto& slot = session.slots[(size_t) s];
        auto* sn = root.createNewChildElement ("SLOT");
        sn->setAttribute ("index", s);
        sn->setAttribute ("chordLength", slot.chords.length);
        sn->setAttribute ("beatsPerChord", slot.chords.beatsPerChord);
        for (int c = 0; c < mjq::kChordBars; ++c)
        {
            auto* cn = sn->createNewChildElement ("CHORD");
            const auto& chord = slot.chords.bars[(size_t) c];
            cn->setAttribute ("bar", c);
            cn->setAttribute ("root", chord.root);
            cn->setAttribute ("kind", (int) chord.kind);
            cn->setAttribute ("bass", chord.bassNote);
            cn->setAttribute ("inversion", chord.inversion);
        }
        for (int t = 0; t < mjq::kSessionTracks; ++t)
        {
            const auto& tr = slot.tracks[(size_t) t];
            auto* tn = sn->createNewChildElement ("TRACK");
            tn->setAttribute ("index", t);
            tn->setAttribute ("enabled", tr.enabled);
            tn->setAttribute ("generator", (int) tr.generator.kind);
            tn->setAttribute ("seed", (int) tr.generator.seed);
            tn->setAttribute ("amount", tr.generator.amount);
            tn->setAttribute ("hits", tr.generator.hits);
            tn->setAttribute ("rotate", tr.generator.rotate);
            tn->setAttribute ("cue", (int) tr.generator.cue.kind);
            tn->setAttribute ("cueN", (int) tr.generator.cue.n);
            tn->setAttribute ("cueOf", (int) tr.generator.cue.of);
            tn->setAttribute ("cueChance", tr.generator.cue.chance);
            tn->setAttribute ("fill", tr.generator.fill);
            if (auto legacy = juce::parseXML (toXml (tr.line, clockMode, {})))
                tn->addChildElement (legacy.release());
        }
    }
    const auto xml = root.toString();
    dest.replaceAll (xml.toRawUTF8(), xml.getNumBytesAsUTF8());
}

void MjqProcessor::setStateInformation (const void* data, int size)
{
    if (data == nullptr || size <= 0) return;
    const juce::String contents = juce::String::fromUTF8 ((const char*) data, size);
    auto root = juce::parseXML (contents);
    if (root == nullptr) return;
    juce::String wants;
    if (root->hasTagName ("MIDIJAQ"))
    {
        // The original projects must open as before, with their line in slot one.
        mjq::Line oldLine;
        auto clock = clockMode;
        if (! fromXml (contents, oldLine, clock, wants)) return;
        session = mjq::Session();
        session.selected = 0;
        session.selectedTrack = 0;
        line = oldLine;
        clockMode = clock;
    }
    else if (root->hasTagName ("MIDIJAQ_SESSION"))
    {
        mjq::Session restored;
        restored.selected = juce::jlimit (0, 127, root->getIntAttribute ("selected"));
        restored.selectedTrack = juce::jlimit (0, 3, root->getIntAttribute ("selectedTrack"));
        restored.chainLength = juce::jlimit (1, 128, root->getIntAttribute ("chain", 1));
        clockMode = (mjq::ClockMode) juce::jlimit (0, 2, root->getIntAttribute ("clock"));
        wants = root->getStringAttribute ("instrument");
        for (auto* sn : root->getChildWithTagNameIterator ("SLOT"))
        {
            const int s = sn->getIntAttribute ("index", -1);
            if (s < 0 || s >= 128) continue;
            restored.touched[(size_t) s] = true;
            auto& slot = restored.slots[(size_t) s];
            slot.chords.length = juce::jlimit (1, 8, sn->getIntAttribute ("chordLength", 4));
            slot.chords.beatsPerChord = juce::jlimit (1, 16, sn->getIntAttribute ("beatsPerChord", 4));
            for (auto* cn : sn->getChildWithTagNameIterator ("CHORD"))
            {
                const int b = cn->getIntAttribute ("bar", -1);
                if (b < 0 || b >= 8) continue;
                auto& chord = slot.chords.bars[(size_t) b];
                chord.root = juce::jlimit (0, 11, cn->getIntAttribute ("root"));
                chord.kind = (mjq::ChordKind) juce::jlimit (0, 8, cn->getIntAttribute ("kind"));
                chord.bassNote = juce::jlimit (0, 120, cn->getIntAttribute ("bass", 48));
                chord.inversion = juce::jlimit (0, 3, cn->getIntAttribute ("inversion"));
            }
            for (auto* tn : sn->getChildWithTagNameIterator ("TRACK"))
            {
                const int t = tn->getIntAttribute ("index", -1);
                if (t < 0 || t >= 4) continue;
                auto& tr = slot.tracks[(size_t) t];
                tr.enabled = tn->getBoolAttribute ("enabled", t == 0);
                tr.generator.kind = (mjq::Generator) juce::jlimit (0, 4, tn->getIntAttribute ("generator"));
                tr.generator.seed = (uint32_t) tn->getIntAttribute ("seed", 1);
                tr.generator.amount = (float) tn->getDoubleAttribute ("amount", 0.5);
                tr.generator.hits = juce::jlimit (0, 32, tn->getIntAttribute ("hits", 5));
                tr.generator.rotate = tn->getIntAttribute ("rotate");
                tr.generator.cue.kind = (gen::Cue::Kind) juce::jlimit (0, 8, tn->getIntAttribute ("cue"));
                tr.generator.cue.n = (uint8_t) juce::jlimit (1, 64, tn->getIntAttribute ("cueN", 1));
                tr.generator.cue.of = (uint8_t) juce::jlimit (1, 64, tn->getIntAttribute ("cueOf", 2));
                tr.generator.cue.chance = (float) juce::jlimit (0.0, 1.0, tn->getDoubleAttribute ("cueChance", 0.5));
                tr.generator.fill = tn->getBoolAttribute ("fill", false);
                if (auto* ln = tn->getChildByName ("MIDIJAQ"))
                {
                    mjq::ClockMode dummy = clockMode;
                    juce::String ignored;
                    fromXml (ln->toString(), tr.line, dummy, ignored);
                    tr.line.partIndex = t;
                }
            }
        }
        session = std::move (restored);
        line = session.current().tracks[(size_t) session.selectedTrack].line;
    }
    else return;
    playingSlot = -1;
    rebuildSession (true);
    if (wants.isNotEmpty() && wants != instrumentFile)
    {
        const juce::File f (wants);
        juce::String err;
        if (f.existsAsFile()) openInstrument (f, err);
        else { instrumentFile = wants; message = "The instrument " + f.getFileName() + " was not where it was: open it again."; version.fetch_add (1); }
    }
}
''')
# The extra controls stay in MidiJaQ's editor, below the seven original lanes. The chrome/pearl
# shared skin is untouched, and the seven-row grid keeps its existing editing behaviour.
edit('Source/app/Editor.cpp')
replace('Source/app/Editor.cpp',
    '    Segmented mode { { "Free", "Follow", "Bass" } }, clock',
    '    Segmented mode { { "Free", "Follow", "Bass", "Parts" } }, clock')
replace('Source/app/Editor.cpp',
    '''    juce::ComboBox rootBox, scaleBox, gridBox;
    Pill openInst''',
    '''    juce::ComboBox rootBox, scaleBox, gridBox;
    juce::ComboBox slotBox, trackBox, writerBox, chordBarBox, chordRootBox, chordKindBox, chordLengthBox, cueBox;
    Pill trackOn { "Line on", true }, fill { "Fill", true };
    Pill openBank { "Open patterns" }, saveBank { "Save .NJQ" };
    Knob chain { "CHAIN", 1.0f, 128.0f, 1.0f }, amount { "CHANGE", 0.0f, 1.0f, 0.5f }, hits { "HITS", 0.0f, 32.0f, 5.0f };
    int chordBar = 0;
    Pill openInst''')
replace('Source/app/Editor.cpp',
    '    juce::Rectangle<int> head, body, side;',
    '    juce::Rectangle<int> head, body, side, under;')
replace('Source/app/Editor.cpp',
    '''            &q.openInst, &q.closeInst, &q.level })''',
    '''            &q.openInst, &q.closeInst, &q.level, &q.slotBox, &q.trackBox, &q.writerBox, &q.chordBarBox,
            &q.chordRootBox, &q.chordKindBox, &q.chordLengthBox, &q.cueBox, &q.trackOn, &q.fill,
            &q.chain, &q.amount, &q.hits, &q.openBank, &q.saveBank })''')
replace('Source/app/Editor.cpp',
    '''    q.mode.setItemTooltip (2, "Bass: it reads the chord you hold and plays under it");''',
    '''    q.mode.setItemTooltip (2, "Bass: play under the chord track (or under keys you hold)");
    q.mode.setItemTooltip (3, "Parts: give this line one voice of the chord track");''')
replace('Source/app/Editor.cpp',
    '''    setSize (1120, 480);
    setResizable (true, true);
    setResizeLimits (900, 420, 1800, 900);''',
    '''    // Slots save automatically when another is chosen. A chain plays one slot per bar.
    for (int i = 0; i < 128; ++i) q.slotBox.addItem ("Slot " + juce::String (i + 1), i + 1);
    for (int i = 0; i < mjq::kSessionTracks; ++i) q.trackBox.addItem ("Line " + juce::String (i + 1), i + 1);
    for (int i = 0; i < 5; ++i) q.writerBox.addItem (mjq::generatorName ((mjq::Generator) i), i + 1);
    for (int i = 0; i < 8; ++i) q.chordBarBox.addItem ("Bar " + juce::String (i + 1), i + 1);
    for (int i = 0; i < 12; ++i) q.chordRootBox.addItem (gen::pitchName (i), i + 1);
    for (int i = 0; i < 9; ++i) q.chordKindBox.addItem (mjq::chordKindName ((mjq::ChordKind) i), i + 1);
    for (int i = 1; i <= 8; ++i) q.chordLengthBox.addItem (juce::String (i) + " bars", i);
    for (int i = 0; i < 9; ++i)
    {
        static const char* names[] = { "Always", "Chance", "Every N", "First", "Not first", "Fill", "Not fill", "Prev", "Not prev" };
        q.cueBox.addItem (names[i], i + 1);
    }
    q.slotBox.setTooltip ("Choose one of 128 saved patterns. Every line and chord is kept in its slot.");
    q.trackBox.setTooltip ("Choose which of the four lines to edit; each sends MIDI on a separate channel.");
    q.writerBox.setTooltip ("JAQ remembers its family. HABIT turns a loop slowly, DRIFT remembers notes, ORBIT spaces hits, CUES chooses when they play.");
    q.chain.setTooltip ("How many consecutive slots play in order, one slot per bar.");
    q.trackOn.setTooltip ("Turn this line on or off. Other lines keep playing.");
    q.chordBarBox.setTooltip ("Choose which bar of the chord progression to edit.");
    q.chordLengthBox.setTooltip ("How many bars the chord progression repeats over.");
    q.cueBox.setTooltip ("CUES decides when a step may play as the line loops.");
    q.fill.setTooltip ("Tell CUES that this pattern is a fill.");
    q.openBank.setTooltip ("Open MidiJaQ pattern slots from a .NJQ file. Instruments and kits are not replaced.");
    q.saveBank.setTooltip ("Save all your MidiJaQ slots and chord progressions as a .NJQ file.");
    q.openBank.onClick = [this]
    {
        auto& q = *parts;
        q.chooser = std::make_unique<juce::FileChooser> ("Open MidiJaQ patterns", juce::File::getSpecialLocation (juce::File::userDocumentsDirectory), "*.njq");
        q.chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [this] (const juce::FileChooser& chooser)
        {
            const auto file = chooser.getResult();
            if (! file.existsAsFile()) return;
            juce::String error;
            if (! proc.loadPatterns (file, error)) proc.message = error;
            refresh();
        });
    };
    q.saveBank.onClick = [this]
    {
        auto& q = *parts;
        q.chooser = std::make_unique<juce::FileChooser> ("Save MidiJaQ patterns", juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("MidiJaQ patterns.njq"), "*.njq");
        q.chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::warnAboutOverwriting, [this] (const juce::FileChooser& chooser)
        {
            const auto file = chooser.getResult();
            if (file == juce::File()) return;
            juce::String error;
            if (! proc.savePatterns (file.withFileExtension ("njq"), error)) proc.message = error;
            refresh();
        });
    };
    q.slotBox.onChange = [this] { proc.chooseSlot (parts->slotBox.getSelectedId() - 1); refresh(); };
    q.trackBox.onChange = [this] { proc.chooseTrack (parts->trackBox.getSelectedId() - 1); refresh(); };
    q.writerBox.onChange = [this] { proc.changeWriter ((mjq::Generator) (parts->writerBox.getSelectedId() - 1)); refresh(); };
    q.trackOn.onClick = [this] { proc.changeTrackEnabled (parts->trackOn.getToggleState()); refresh(); };
    q.chain.step = 1.0f; q.hits.step = 1.0f;
    q.chain.toText = [] (float v) { return juce::String ((int) std::round (v)); };
    q.hits.toText = q.chain.toText;
    q.amount.toText = q.dialect.toText;
    q.chain.onChange = [this] (float v) { proc.changeChain ((int) std::round (v)); };
    q.amount.onChange = [this] (float v)
    {
        auto& g = proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator;
        g.amount = v;
        g.cue.chance = v;
        proc.rebuildSession();
    };
    q.hits.onChange = [this] (float v)
    {
        proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator.hits = (int) std::round (v);
        proc.rebuildSession();
    };
    q.cueBox.onChange = [this]
    {
        auto& g = proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator;
        g.cue.kind = (gen::Cue::Kind) juce::jlimit (0, 8, parts->cueBox.getSelectedId() - 1);
        proc.rebuildSession();
    };
    q.fill.onClick = [this]
    {
        proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator.fill = parts->fill.getToggleState();
        proc.rebuildSession();
    };
    q.chordBarBox.onChange = [this] { parts->chordBar = parts->chordBarBox.getSelectedId() - 1; refresh(); };
    auto chordChange = [this]
    {
        auto c = proc.session.current().chords.bars[(size_t) parts->chordBar];
        c.root = parts->chordRootBox.getSelectedId() - 1;
        c.kind = (mjq::ChordKind) (parts->chordKindBox.getSelectedId() - 1);
        proc.changeChord (parts->chordBar, c);
        refresh();
    };
    q.chordRootBox.onChange = chordChange;
    q.chordKindBox.onChange = chordChange;
    q.chordLengthBox.onChange = [this]
    {
        proc.session.current().chords.length = parts->chordLengthBox.getSelectedId();
        proc.rebuildSession();
    };

    setSize (1240, 680);
    setResizable (true, true);
    setResizeLimits (1050, 610, 1800, 1000);''')
replace('Source/app/Editor.cpp',
    '''    q.mode.setSelected ((int) L.mode);
    q.clock''',
    '''    q.mode.setSelected ((int) L.mode);
    q.slotBox.setSelectedId (proc.session.selected + 1, juce::dontSendNotification);
    q.trackBox.setSelectedId (proc.session.selectedTrack + 1, juce::dontSendNotification);
    const auto& tr = proc.session.current().tracks[(size_t) proc.session.selectedTrack];
    q.trackOn.setToggleState (tr.enabled, juce::dontSendNotification);
    q.writerBox.setSelectedId ((int) tr.generator.kind + 1, juce::dontSendNotification);
    q.chain.setValue ((float) proc.session.chainLength);
    q.amount.setValue (tr.generator.amount);
    q.hits.setValue ((float) tr.generator.hits);
    q.fill.setToggleState (tr.generator.fill, juce::dontSendNotification);
    q.cueBox.setSelectedId ((int) tr.generator.cue.kind + 1, juce::dontSendNotification);
    q.chordBarBox.setSelectedId (q.chordBar + 1, juce::dontSendNotification);
    const auto& ch = proc.session.current().chords.bars[(size_t) q.chordBar];
    q.chordRootBox.setSelectedId (ch.root + 1, juce::dontSendNotification);
    q.chordKindBox.setSelectedId ((int) ch.kind + 1, juce::dontSendNotification);
    q.chordLengthBox.setSelectedId (proc.session.current().chords.length, juce::dontSendNotification);
    q.clock''')
replace('Source/app/Editor.cpp',
    '''    paintPlate (g, q.side.toFloat(), 12.0f);''',
    '''    paintPlate (g, q.side.toFloat(), 12.0f);
    paintPlate (g, q.under.toFloat(), 12.0f);''')
replace('Source/app/Editor.cpp',
    '''    paintLabel (g, "Direction", { q.direction.getX(), q.direction.getY() - 14, 80, 12 }, juce::Justification::centredLeft, 8.0f);''',
    '''    paintLabel (g, "Direction", { q.direction.getX(), q.direction.getY() - 14, 80, 12 }, juce::Justification::centredLeft, 8.0f);
    paintLabel (g, "PATTERNS & LINES", { q.under.getX() + 12, q.under.getY() + 7, 220, 14 }, juce::Justification::centredLeft, 9.0f);
    paintLabel (g, "CHORD TRACK", { q.under.getX() + 12, q.under.getY() + 92, 220, 14 }, juce::Justification::centredLeft, 9.0f);''')
replace('Source/app/Editor.cpp',
    '''    q.body = r;
    q.grid.setBounds (q.body.reduced (0, 2));''',
    '''    q.body = r;
    const bool compact = getHeight() < 590;
    q.under = q.body.removeFromBottom (compact ? 0 : 164);
    if (! compact) q.body.removeFromBottom (8);
    for (juce::Component* c : std::initializer_list<juce::Component*> { &q.slotBox, &q.trackBox, &q.writerBox, &q.chordBarBox,
            &q.chordRootBox, &q.chordKindBox, &q.chordLengthBox, &q.cueBox, &q.trackOn, &q.fill, &q.chain, &q.amount, &q.hits,
            &q.openBank, &q.saveBank })
        c->setVisible (! compact);
    q.grid.setBounds (q.body.reduced (0, 2));

    const int x0 = q.under.getX() + 12, y0 = q.under.getY() + 27;
    q.slotBox.setBounds (x0, y0, 88, 26);
    q.trackBox.setBounds (x0 + 94, y0, 74, 26);
    q.trackOn.setBounds (x0 + 174, y0, 74, 26);
    q.chain.setBounds (x0 + 254, y0 - 7, 55, 65);
    q.writerBox.setBounds (x0 + 315, y0, 91, 26);
    q.amount.setBounds (x0 + 412, y0 - 7, 60, 65);
    q.hits.setBounds (x0 + 477, y0 - 7, 55, 65);
    q.cueBox.setBounds (x0, y0 + 37, 148, 26);
    q.fill.setBounds (x0 + 155, y0 + 37, 67, 26);
    q.openBank.setBounds (x0 + 230, y0 + 37, 132, 26);
    q.saveBank.setBounds (x0 + 370, y0 + 37, 120, 26);
    const int cy = q.under.getY() + 111;
    q.chordBarBox.setBounds (x0, cy, 84, 27);
    q.chordRootBox.setBounds (x0 + 91, cy, 71, 27);
    q.chordKindBox.setBounds (x0 + 169, cy, 120, 27);
    q.chordLengthBox.setBounds (x0 + 298, cy, 103, 27);''')

edit('tools/HostTest.cpp')
replace('tools/HostTest.cpp',
    '    std::printf ("6. a long random session (seed %d)\\n", seed);',
    '''    std::printf ("6. four lines, slots and .NJQ patterns\\n");
    {
        proc->chooseSlot (0);
        proc->chooseTrack (0);
        proc->line.mode = mjq::Mode::Free;
        proc->line.traffic = 1.0f;
        proc->lineChanged();
        proc->chooseTrack (1);
        proc->changeTrackEnabled (true);
        proc->line.mode = mjq::Mode::Parts;
        proc->line.traffic = 1.0f;
        proc->lineChanged();
        mjq::Chord c;
        c.root = 0; c.kind = mjq::ChordKind::Major;
        proc->changeChord (0, c);
        host.playing = true; host.ppq = 0.0; proc->clockMode = mjq::ClockMode::Song;
        const auto together = run (*proc, host, 80);
        bool first = false, second = false;
        for (const auto& m : together)
            if (m.isNoteOn()) { first |= m.getChannel() == 1; second |= m.getChannel() == 2; }
        CHECK (first && second, "two lines play at once on their own MIDI channels");

        proc->chooseSlot (5);
        proc->chooseTrack (1);
        proc->line.mode = mjq::Mode::Bass;
        proc->line.traffic = 1.0f;
        proc->changeTrackEnabled (true);
        proc->lineChanged();
        proc->changeChain (2);
        juce::MemoryBlock state;
        proc->getStateInformation (state);
        auto copy = std::make_unique<MjqProcessor>();
        copy->setPlayConfigDetails (0, 2, 48000.0, 512);
        copy->prepareToPlay (48000.0, 512);
        copy->setStateInformation (state.getData(), (int) state.getSize());
        CHECK (copy->session.selected == 5 && copy->session.chainLength == 2
               && copy->session.current().tracks[1].enabled
               && copy->session.current().tracks[1].line.mode == mjq::Mode::Bass,
               "a saved project keeps its slots and chord voices (%d bytes)", (int) state.getSize());

        const auto pattern = dir.getChildFile ("MidiJaQ session.njq");
        juce::String error;
        const bool saved = proc->savePatterns (pattern, error);
        const bool loaded = saved && copy->loadPatterns (pattern, error);
        CHECK (saved && loaded && copy->session.selected == 5 && copy->session.chainLength == 2,
               "a .NJQ file saves and opens the pattern bank: %s", error.toRawUTF8());
        copy->releaseResources();
        proc->chooseTrack (0); proc->chooseSlot (0); proc->changeChain (1);
        proc->clockMode = mjq::ClockMode::Pattern;
    }

    std::printf ("7. a long random session (seed %d)\\n", seed);''')

edit('CMakeLists.txt')
replace('CMakeLists.txt', 'foreach (t test_jaq test_clock)', 'foreach (t test_jaq test_clock test_session)')
# MIDIJAQ's advanced generator and chord controls use the same house-style knobs/pills.
replace('Source/app/Editor.cpp',
    '    juce::ComboBox slotBox, trackBox, writerBox, chordBarBox, chordRootBox, chordKindBox, chordLengthBox, cueBox;',
    '    juce::ComboBox slotBox, trackBox, writerBox, chordBarBox, chordRootBox, chordKindBox, chordLengthBox, cueBox, chordInversionBox;')
replace('Source/app/Editor.cpp',
    '    Knob chain { "CHAIN", 1.0f, 128.0f, 1.0f }, amount { "CHANGE", 0.0f, 1.0f, 0.5f }, hits { "HITS", 0.0f, 32.0f, 5.0f };',
    '''    Knob chain { "CHAIN", 1.0f, 128.0f, 1.0f }, amount { "CHANGE", 0.0f, 1.0f, 0.5f }, hits { "HITS", 0.0f, 32.0f, 5.0f };
    Knob rotate { "ROTATE", 0.0f, 31.0f, 0.0f }, cueN { "ON", 1.0f, 16.0f, 1.0f }, cueOf { "EVERY", 1.0f, 16.0f, 2.0f };
    Knob bassNote { "BASS", 24.0f, 72.0f, 48.0f };''')
replace('Source/app/Editor.cpp',
    '''&q.chain, &q.amount, &q.hits, &q.openBank, &q.saveBank })''',
    '''&q.chain, &q.amount, &q.hits, &q.rotate, &q.cueN, &q.cueOf, &q.bassNote,
            &q.chordInversionBox, &q.openBank, &q.saveBank })''')
replace('Source/app/Editor.cpp',
    '    for (int i = 1; i <= 8; ++i) q.chordLengthBox.addItem (juce::String (i) + " bars", i);',
    '''    for (int i = 1; i <= 8; ++i) q.chordLengthBox.addItem (juce::String (i) + " bars", i);
    for (int i = 0; i < 4; ++i) q.chordInversionBox.addItem ("Invert " + juce::String (i), i + 1);''')
replace('Source/app/Editor.cpp',
    '    q.cueBox.setTooltip ("CUES decides when a step may play as the line loops.");',
    '''    q.cueBox.setTooltip ("CUES decides when a step may play as the line loops.");
    q.cueN.setTooltip ("For Every N, which repetition of the loop should play the notes.");
    q.cueOf.setTooltip ("For Every N, how many loop repetitions are in the cycle.");
    q.rotate.setTooltip ("For ORBIT, move the evenly spaced notes around the grid.");
    q.bassNote.setTooltip ("Choose the octave in which the chord progression sits, from C0 to C4.");
    q.chordInversionBox.setTooltip ("Lift low chord voices by an octave to change its shape.");''')
replace('Source/app/Editor.cpp',
    '    q.chain.step = 1.0f; q.hits.step = 1.0f;',
    '''    q.chain.step = 1.0f; q.hits.step = 1.0f;
    q.rotate.step = 1.0f; q.cueN.step = 1.0f; q.cueOf.step = 1.0f; q.bassNote.step = 1.0f;''')
replace('Source/app/Editor.cpp',
    '    q.hits.toText = q.chain.toText;',
    '''    q.hits.toText = q.chain.toText;
    q.rotate.toText = q.chain.toText; q.cueN.toText = q.chain.toText; q.cueOf.toText = q.chain.toText;
    q.bassNote.toText = [] (float v) { return gen::noteName ((int) std::lround (v)); };''')
replace('Source/app/Editor.cpp',
    '    q.cueBox.onChange = [this]',
    '''    q.rotate.onChange = [this] (float v)
    {
        proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator.rotate = (int) std::lround (v);
        proc.rebuildSession();
    };
    q.cueN.onChange = [this] (float v)
    {
        proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator.cue.n = (uint8_t) std::lround (v);
        proc.rebuildSession();
    };
    q.cueOf.onChange = [this] (float v)
    {
        proc.session.current().tracks[(size_t) proc.session.selectedTrack].generator.cue.of = (uint8_t) std::lround (v);
        proc.rebuildSession();
    };
    q.cueBox.onChange = [this]''')
replace('Source/app/Editor.cpp',
    '''        c.kind = (mjq::ChordKind) (parts->chordKindBox.getSelectedId() - 1);
        proc.changeChord (parts->chordBar, c);''',
    '''        c.kind = (mjq::ChordKind) (parts->chordKindBox.getSelectedId() - 1);
        c.inversion = parts->chordInversionBox.getSelectedId() - 1;
        c.bassNote = (int) std::lround (parts->bassNote.getValue());
        proc.changeChord (parts->chordBar, c);''')
replace('Source/app/Editor.cpp',
    '''    q.chordRootBox.onChange = chordChange;
    q.chordKindBox.onChange = chordChange;''',
    '''    q.chordRootBox.onChange = chordChange;
    q.chordKindBox.onChange = chordChange;
    q.chordInversionBox.onChange = chordChange;
    q.bassNote.onChange = [this, chordChange] (float) { chordChange(); };''')
replace('Source/app/Editor.cpp',
    '''    q.hits.setValue ((float) tr.generator.hits);''',
    '''    q.hits.setValue ((float) tr.generator.hits);
    q.rotate.setValue ((float) tr.generator.rotate);
    q.cueN.setValue ((float) tr.generator.cue.n);
    q.cueOf.setValue ((float) tr.generator.cue.of);''')
replace('Source/app/Editor.cpp',
    '''    q.chordKindBox.setSelectedId ((int) ch.kind + 1, juce::dontSendNotification);''',
    '''    q.chordKindBox.setSelectedId ((int) ch.kind + 1, juce::dontSendNotification);
    q.chordInversionBox.setSelectedId (ch.inversion + 1, juce::dontSendNotification);
    q.bassNote.setValue ((float) ch.bassNote);''')
replace('Source/app/Editor.cpp',
    '''&q.openBank, &q.saveBank })
        c->setVisible''',
    '''&q.rotate, &q.cueN, &q.cueOf, &q.bassNote, &q.chordInversionBox, &q.openBank, &q.saveBank })
        c->setVisible''')
replace('Source/app/Editor.cpp',
    '''    q.cueBox.setBounds (x0, y0 + 37, 148, 26);''',
    '''    q.rotate.setBounds (x0 + 539, y0 - 7, 60, 65);
    q.cueN.setBounds (x0 + 604, y0 - 7, 60, 65);
    q.cueOf.setBounds (x0 + 669, y0 - 7, 60, 65);
    q.cueBox.setBounds (x0, y0 + 37, 148, 26);''')
replace('Source/app/Editor.cpp',
    '''    q.chordLengthBox.setBounds (x0 + 298, cy, 103, 27);''',
    '''    q.chordLengthBox.setBounds (x0 + 298, cy, 103, 27);
    q.chordInversionBox.setBounds (x0 + 409, cy, 93, 27);
    q.bassNote.setBounds (x0 + 509, cy - 11, 72, 62);''')
# Integration corrections found when reviewing the actual MIDIJAQ API.
# All changes here are still to MIDIJAQ's private branch-local files.
replace('Source/app/Processor.cpp',
    '    voices.setInstrument (shared);',
    '    voices.setInstrument (shared);\n    for (auto& v : otherVoices) v.setInstrument (shared);')
replace('Source/app/Processor.cpp',
    '    voices.setInstrument (nullptr);\n    voices.letGo.store (true);',
    '''    voices.setInstrument (nullptr);
    voices.letGo.store (true);
    for (auto& v : otherVoices) { v.setInstrument (nullptr); v.letGo.store (true); }''')
replace('Source/app/Processor.cpp',
    '''    voices.prepare (sampleRate);
    if (auto cur = std::atomic_load (&loaded)) voices.setInstrument (cur);''',
    '''    voices.prepare (sampleRate);
    for (auto& v : otherVoices) v.prepare (sampleRate);
    if (auto cur = std::atomic_load (&loaded))
    {
        voices.setInstrument (cur);
        for (auto& v : otherVoices) v.setInstrument (cur);
    }''')
replace('Source/app/Processor.cpp',
    '''segment, out, 256, &slot.chords, &tr.generator);''',
    '''segment, out, 256, &slot.chords, &tr.generator,
                                           host.valid ? beat : seq.positionInPass());''')
replace('Source/core/Player.h',
    'chord = progression->notesAt (t + chordBeat);',
    'chord = progression->notesAt (chordBeat + t - from);')
replace('Source/app/Processor.cpp',
    '''    playingSlot = -1;
    rebuildSession (true);
    if (wants.isNotEmpty() && wants != instrumentFile)''',
    '''    playingSlot = -1;
    rebuildSession (true);
    if (wants.isEmpty() && instrumentFile.isNotEmpty()) closeInstrument();
    if (wants.isNotEmpty() && wants != instrumentFile)''')
# Evolving writers. A fixed bank of sixteen passes is prepared on the message thread;
# the sound thread selects the current round without making allocations or touching shared code.
replace('Source/app/Processor.h',
    '''    struct Prepared
    {
        mjq::Session state;
        std::array<std::array<mjq::Pass, mjq::kSessionTracks>, mjq::kSessionSlots> passes {};
    };''',
    '''    struct Prepared
    {
        mjq::Session state;
        std::array<std::array<mjq::Pass, mjq::kSessionTracks>, mjq::kSessionSlots> passes {};
        std::array<std::array<std::shared_ptr<const std::vector<mjq::Pass>>, mjq::kSessionTracks>, mjq::kSessionSlots> evolving {};
    };''')
replace('Source/app/Processor.cpp',
    '''    if (full || old == nullptr)
    {
        for (int s = 0; s < mjq::kSessionSlots; ++s)
            for (int t = 0; t < mjq::kSessionTracks; ++t)
                next->passes[(size_t) s][(size_t) t] = mjq::generatedPass (next->state.slots[(size_t) s].tracks[(size_t) t]);
    }
    else
    {
        for (int t = 0; t < mjq::kSessionTracks; ++t)
            next->passes[(size_t) session.selected][(size_t) t] = mjq::generatedPass (next->state.current().tracks[(size_t) t]);
    }''',
    '''    auto prepareTrack = [&] (int s, int t)
    {
        const auto& tr = next->state.slots[(size_t) s].tracks[(size_t) t];
        next->passes[(size_t) s][(size_t) t] = mjq::generatedPass (tr);
        auto& rounds = next->evolving[(size_t) s][(size_t) t];
        if (tr.generator.kind == mjq::Generator::HABIT || tr.generator.kind == mjq::Generator::DRIFT)
        {
            std::vector<mjq::Pass> prepared;
            prepared.reserve (mjq::kEvolutionRounds);
            prepared.push_back (next->passes[(size_t) s][(size_t) t]);
            for (int r = 1; r < mjq::kEvolutionRounds; ++r)
                prepared.push_back (mjq::generatedPass (tr, (uint64_t) r));
            rounds = std::make_shared<const std::vector<mjq::Pass>> (std::move (prepared));
        }
        else rounds.reset();
    };
    if (full || old == nullptr)
    {
        for (int s = 0; s < mjq::kSessionSlots; ++s)
            for (int t = 0; t < mjq::kSessionTracks; ++t) prepareTrack (s, t);
    }
    else
    {
        for (int t = 0; t < mjq::kSessionTracks; ++t) prepareTrack (session.selected, t);
    }''')
replace('Source/core/Player.h',
    '''                 const GeneratorSettings* writer = nullptr, double chordBeat = 0.0)''',
    '''                 const GeneratorSettings* writer = nullptr, double chordBeat = 0.0,
                 const std::vector<Pass>* evolving = nullptr)''')
replace('Source/core/Player.h',
    '''            for (long long k = k0; k <= k1; ++k)
            {
                const double base = (double) k * pass.beats;
                bool prevPassed = true;
                for (const auto& e : pass.events)
                {
                    const bool permitted = writer == nullptr || cueAllows (*writer, (uint64_t) std::max (0ll, k), e.step, prevPassed);''',
    '''            const long long songRound = mode == ClockMode::Song && host.valid
                ? (long long) std::floor (std::max (0.0, host.ppq) / pass.beats) : 0;
            for (long long k = k0; k <= k1; ++k)
            {
                const double base = (double) k * pass.beats;
                const uint64_t round = (uint64_t) std::max (0ll,
                    mode == ClockMode::Song && host.valid ? songRound + (k - k0) : k);
                const auto& currentPass = evolving != nullptr && ! evolving->empty()
                    ? (*evolving)[(size_t) (round % evolving->size())] : pass;
                bool prevPassed = true;
                for (const auto& e : currentPass.events)
                {
                    const bool permitted = writer == nullptr || cueAllows (*writer, round, e.step, prevPassed);''')
replace('Source/app/Processor.cpp',
    '''segment, out, 256, &slot.chords, &tr.generator,
                                           host.valid ? beat : seq.positionInPass());''',
    '''segment, out, 256, &slot.chords, &tr.generator,
                                           host.valid ? beat : seq.positionInPass(),
                                           snapshot->evolving[(size_t) slotNumber][(size_t) track].get());''')
replace('CMakeLists.txt',
    'foreach (t test_jaq test_clock test_session)',
    'foreach (t test_jaq test_clock test_session test_evolving)')
# Commit nothing. Check the entire edit for every expected anchor, then write all files in one operation.
new_header = source / 'Source/core/Session.h'
new_test = source / 'tools/test_session.cpp'
new_evolving_test = source / 'tools/test_evolving.cpp'
if not new_header.is_file() or not new_test.is_file() or not new_evolving_test.is_file(): raise SystemExit('Missing new MidiJaQ source or test beside apply_midijaq.py')
new_path = root / 'Source/core/Session.h'
if new_path.exists(): raise SystemExit('Source/core/Session.h already exists; not overwriting an unknown implementation')
if (root / 'tools/test_session.cpp').exists(): raise SystemExit('tools/test_session.cpp already exists; not overwriting an unknown test')
if (root / 'tools/test_evolving.cpp').exists(): raise SystemExit('tools/test_evolving.cpp already exists; not overwriting an unknown test')
if not (root / 'Source/core/Jaq.h').is_file(): raise SystemExit('Not a midijaq source checkout')
for name, content in files.items():
    (root / name).write_text(content, encoding='utf-8')
new_path.write_bytes(new_header.read_bytes())
(root / 'tools/test_session.cpp').write_bytes(new_test.read_bytes())
(root / 'tools/test_evolving.cpp').write_bytes(new_evolving_test.read_bytes())
print(f'Updated {len(files)} MidiJaQ source files and added Session.h and two tests. No Git commit or push was made.')
print('Review git diff, then build and run the tests before using the plugin.')
